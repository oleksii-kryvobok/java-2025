package com.calculator.integration;

public class FormulaIntegrationTest {
}
