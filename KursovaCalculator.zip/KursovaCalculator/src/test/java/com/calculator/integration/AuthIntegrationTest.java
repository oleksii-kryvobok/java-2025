package com.calculator.integration;

public class AuthIntegrationTest {
}
