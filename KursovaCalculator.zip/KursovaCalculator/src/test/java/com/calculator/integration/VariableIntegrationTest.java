package com.calculator.integration;

public class VariableIntegrationTest {
}
