package com.calculator.dto;
import lombok.Data;

@Data
public class VariableDTO {
    private String name;
    private String value;
}
