package com.calculator.dto;
import lombok.Data;

@Data
public class UserInfoDTO {
    private String username;
    private String email;
}
