package com.calculator.dto;
import lombok.Data;

@Data
public class CalculationRequestDTO {
    private String expression;
    //private String result;
}
