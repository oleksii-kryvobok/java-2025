package com.calculator.dto;
import lombok.Data;

@Data
public class FormulaDTO {
    private String name;
    private String expression;
}
